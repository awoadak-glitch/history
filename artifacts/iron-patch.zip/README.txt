AWR IronFingerprint trial patch

classes29.dex SHA-256: 074b8adca88f48074671e6637271b1dce4678f0b93c39c3dbf3a91dbb6a9761c
Base: AWR-World-internal-tabs.apk
Base SHA-256: 82570927efa97baaff6ac2bcdc5326f0ac0008782b38aec3eb2d752d4c3c9a0b
Native input: owner-supplied Oscar TV 1.1.4 APK
Native APK SHA-256: e15d2de82257e55a5ea7ffef7a78ec205caf0c02ddfa7b80673dba68006226d7

Use repository tooling/patch_apk.py with --input BASE --dex classes29.dex
--iron-apk OSCAR_APK --compiler APKSIG_JAR --keystore YOUR_EXISTING_AWR_KEY
--alias awr20260920 --output RESULT.apk --report REPORT.json.
Provide the key password through AWR_KEYSTORE_PASSWORD, never a command argument.
Do not generate a replacement signing key. Source code / signing tools: f23a958.
Original native libraries and private signing key are not included in this archive.

Verification: 18 local fixture tests; no Android-device/native/server success claim.
Original integrity failures remain enforced; no signature or package substitution.
The DEX preserves approved Drama/season state and hidden HiTV tab behavior.
