Copy these entries into an exact copy of Anime Witcher 1.3.8. Replace existing entries, then sign in MT Manager. This is a development checkpoint.
